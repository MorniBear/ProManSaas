create trigger tri_INSTERT_S on s
for insert
as
declare @S_age tinyint
select @S_age=S.age
from s
if @S_age not between 15 and 30
   rollback transaction
go

