create view view_s_grade
as select s.sno,sname,cname,grade
from s,sc,c
where s.sno=sc.sno and sc.sno=c.cno
go

