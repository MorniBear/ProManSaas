create trigger tgr_message
on s
after insert,update
as raiserror('tgr_message 触发器被触发',16,10)
go

