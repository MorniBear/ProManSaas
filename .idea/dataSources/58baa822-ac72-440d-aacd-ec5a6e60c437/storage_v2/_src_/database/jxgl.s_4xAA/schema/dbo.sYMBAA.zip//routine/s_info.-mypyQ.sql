create procedure s_info @s_name char(8)
as
  declare @s_count int
  declare @s_avg real
  select @s_count = COUNT(cno), @s_avg = avg(grade)
  from S
         JOIN SC ON S.sno = Sc.sno and sname = @s_name
  print @s_name + '同学总共选修了' + str(@s_count) + '门课成绩 平均成绩为：' + str(@s_avg)
go

