create trigger delete_sc_s on s
instead of delete
as
declare @s_no char(9)
select @s_no=sno from deleted
delete from sc
where sno=@s_no
delete from s
where sno=@s_no
go

