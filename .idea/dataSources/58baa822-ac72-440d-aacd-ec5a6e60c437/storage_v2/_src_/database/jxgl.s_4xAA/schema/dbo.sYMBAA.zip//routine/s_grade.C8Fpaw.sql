create procedure s_grade
as
select s.sno,sname,sex,age
from S join sc on S.sno=sc.sno join C on sc.sno=C.cno
go

