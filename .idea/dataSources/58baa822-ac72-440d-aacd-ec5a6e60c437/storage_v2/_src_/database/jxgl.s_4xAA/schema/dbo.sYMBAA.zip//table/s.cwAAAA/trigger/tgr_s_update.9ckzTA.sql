CREATE TRIGGER tgr_s_update
ON S
FOR UPDATE
AS
DECLARE @oldName char(8),@newName char(8)
--更新前的数据
SELECT @oldName=sname FROM deleted
IF(exists (SELECT * FROM S WHERE sname = @oldName))
	BEGIN
	--更新后的数据
	SELECT @newName=sname FROM inserted
	UPDATE S SET sname=REPLACE(sname,@oldName,@newName) WHERE sname LIKE
								'%'+@oldName+'%'
	PRINT '级联修改数据成功'
	END
ELSE
	PRINT '无需修改S表'
go

