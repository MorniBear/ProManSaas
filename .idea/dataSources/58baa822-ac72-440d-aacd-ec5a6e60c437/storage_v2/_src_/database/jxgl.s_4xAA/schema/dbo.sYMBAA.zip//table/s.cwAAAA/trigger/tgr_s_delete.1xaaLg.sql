  ---delete删除类型触发器  X*Y
create trigger tgr_s_delete
on s
   for delete  --删除触发
as
print'备份数据中'
if(object_id('s_backup','U') is not null)
    --存在S_back，直接插入数据
 insert into s_backup select sno,sname from deleted
 else
    --不存在stu_backup,创建后再插入
select * into s_backup from deleted
print '备份数据成功！'
  go

