create proc table_info @table varchar(30)
as
  select TABLE_NAME = sys.objects.name, Index_NAME =sys.indexes.name, Index_ID = sys.indexes.index_id
  from sys.indexes
         inner join sys.objects on sys.objects.object_id = sys.indexes.index_id
  where sys.objects.name = @table
go

